package com.SpringBoot_Redis_zj.service;

import com.SpringBoot_Redis_zj.entity.User;

public interface UserService {

	boolean addUser(User user);
	
	boolean updateUser(User user);

	boolean deleteUser(int id);
	
	User findByUserId(int id);

}
