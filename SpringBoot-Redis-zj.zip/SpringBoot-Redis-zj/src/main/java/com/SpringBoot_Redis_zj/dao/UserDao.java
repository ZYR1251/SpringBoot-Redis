package com.SpringBoot_Redis_zj.dao;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.SpringBoot_Redis_zj.entity.User;
import com.SpringBoot_Redis_zj.util.RedisUtil;
import com.alibaba.fastjson.JSON;

@Repository
public class UserDao {

	@Resource
	private RedisUtil redisUtil;
	
	public void addUser(User user) {
		redisUtil.set(String.valueOf(user.getId()), user.toString());
	}

	public void updateUser(User user) {
		redisUtil.set(String.valueOf(user.getId()), user.toString());
	}

	public void deleteUser(int id) {
		redisUtil.del(String.valueOf(id));
	}

	public User findByUserId(int id) {
		String data = redisUtil.get(String.valueOf(id)).toString();
		User user = JSON.parseObject(data, User.class);
		return  user;
	}

}
